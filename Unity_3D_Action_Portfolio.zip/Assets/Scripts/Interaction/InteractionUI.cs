using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;


/// <summary>
/// �÷��̾ �ٶ󺸰� �ִ� ��ȣ�ۿ� ������Ʈ�� �ȳ� UI
/// </summary>
public class InteractionUI : MonoBehaviour
{
    [Header("Reference")]
    [SerializeField] private PlayerInteraction playerInteraction;
    [SerializeField] private TextMeshProUGUI interactionText;

    private void Update()
    {
        if (playerInteraction == null || interactionText == null)
            return;

        IInteractable interactable = playerInteraction.GetCurrentInteractable();

        if (interactable == null)
        {
            interactionText.gameObject.SetActive(false);
            return;
        }

        interactionText.gameObject.SetActive(true);

        interactionText.text = $"[E] {interactable.GetInteractionText()}";
    }
}
