using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// �÷��̾��� ��ȣ�ۿ��� ����ϴ� Ŭ����
/// </summary>

public class PlayerInteraction : MonoBehaviour
{
    [Header("Interaction")]
    [SerializeField] private float interactDistance = 2f;
    [SerializeField] private LayerMask interactLayer;

    private PlayerMovement player;
    private PlayerInputController input;
    private IInteractable currentInteractable;

    private void Awake()
    {
        player = GetComponent<PlayerMovement>();
        input = GetComponent<PlayerInputController>();
    }

    private void Update()
    {
        DetectInteraction();

        // EŰ �Է�
        if(input.InteractPressed)
        {
            TryInteract();
            input.ConsumeInteract();
        }
    }

    /// <summary>
    /// ����׿� Ray ǥ��
    /// </summary>
    private void DetectInteraction()
    {
        Vector3 origin = transform.position + Vector3.up;
        Vector3 direction = transform.forward;

        Debug.DrawRay(origin, direction * interactDistance, Color.green);

        currentInteractable = null;

        Ray ray = new Ray(origin, direction);

        if(Physics.Raycast(ray, out RaycastHit hit, interactDistance, interactLayer))
        {
            currentInteractable = hit.collider.GetComponent<IInteractable>();
        }
    }

    /// <summary>
    /// ��ȣ�ۿ� �õ�
    /// </summary>
    private void TryInteract()
    {
        if (currentInteractable == null)
            return;

        currentInteractable.Interact(player);
    }

    /// <summary>
    /// ���� �ٶ󺸰� �ִ� ��ȣ�ۿ� ������Ʈ ��ȯ
    /// UI���� ����� ����
    /// </summary>
    public IInteractable GetCurrentInteractable()
    {
        return currentInteractable;
    }
}