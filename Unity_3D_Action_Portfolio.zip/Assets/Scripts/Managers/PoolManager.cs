using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PoolManager : MonoBehaviour
{
    public static PoolManager Instance;

    // Inspector���� ����� pool ����
    [System.Serializable]
    public class  PoolData
    {
        public string key;  // Pool �̸�
        public PoolObject prefab;   // ������
        public int count = 10;  // �ʱ� ���� ����
    }

    // Inspector���� ���� pool ���
    [Header("Pool List")]
    [SerializeField]
    private List<PoolData> poolList =
        new List<PoolData>();

    // ���� Pool ����
    private Dictionary<string, Pool> pools =
        new Dictionary<string, Pool>();

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        // Inspector���� ����� Pool ����
        foreach (PoolData data in poolList)
        {
            Pool pool =
                new Pool(data.prefab, data.count, transform);

            pools.Add(data.key, pool);
        }
    }

    // Spawn
    public PoolObject Spawn(string key)
    {
        if (!pools.ContainsKey(key))
        {
            Debug.LogError($"Pool {key} ����");
            return null;
        }

        return pools[key].GetObject();
    }
}
