using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(
    fileName = "PlayerData",
    menuName = "Game Data/Player Data")]

public class PlayerData : ScriptableObject
{
    [Header("Movement")]
    public float moveSpeed = 5f;
    public float runSpeed = 8f;

    [Header("Jump")]
    public float jumpForce = 5f;

    // �ڿ��� Ÿ��
    public float coyoteTime = 0.1f;

    // ���� ����
    public float jumpBufferTime = 0.1f;

    [Header("Fall")]
    // ���� ���� ����
    public float fallGraceTime = 0.12f;

    // Hard Landing ����
    public float hardLandingThreshold = -7f;

    [Header("Dash")]
    public float dashSpeed = 15f;

    // �뽬 ��ٿ�
    public float dashCooldown = 1f;
}
