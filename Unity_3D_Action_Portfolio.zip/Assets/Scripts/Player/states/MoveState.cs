using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveState : IPlayerState
{
    private PlayerMovement player;
    private Rigidbody rb;

    public MoveState(PlayerMovement player)
    {
        this.player = player;
        this.rb = player.GetRigidbody();
    }

    public void Enter()
    {

    }

    public void Update()
    {
        Move();

        // ���� ������ ������ ��� - FallState ����
        if (player.ShouldFall())
        {
            player.ChangeState(new FallState(player));
            return;
        }

        // Idle ��ȯ
        if (!player.HasMoveInput())
        {
            player.ChangeState(new IdleState(player));
            return;
        }

        // Run ��ȯ
        if(player.IsRunning())
        {
            player.ChangeState(new RunState(player));
            return;
        }

        // Jump ��ȯ
        if (player.CanJump())
        {
            player.ConsumeJumpBuffer();
            player.ChangeState(new JumpState(player));
            return;
        }

        // Dash ��ȯ
        if (player.DashPressed() && player.CanDash())
        {
           player.ChangeState(new DashState(player));
            return;
        }
    }

    public void Exit()
    {

    }

    private void Move()
    {
        Vector2 input = player.GetMoveInput();

        Vector3 forward = Camera.main.transform.forward;
        Vector3 right = Camera.main.transform.right;

        forward.y = 0;
        right.y = 0;

        forward.Normalize();
        right.Normalize();

        Vector3 moveDir = forward * input.y + right * input.x;
        moveDir.Normalize();

        // ���� �̵� ����
        if(player.OnSlope())
        {
            moveDir = Vector3.ProjectOnPlane(moveDir, player.GetSlopeNormal()).normalized;
        }

        Vector3 velocity = rb.velocity;

        float speedMultiper = player.GetMoveSpeedMultiplier();

        velocity.x = moveDir.x * player.MoveSpeed * speedMultiper;
        velocity.z = moveDir.z * player.MoveSpeed * speedMultiper;

        rb.velocity = velocity;

        player.Rotate(moveDir);
    }
}
