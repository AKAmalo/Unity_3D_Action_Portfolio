using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IdleState : IPlayerState
{
    private PlayerMovement player;

    public IdleState(PlayerMovement player)
    {
        this.player = player;
    }

    public void Enter()
    {
        // Idle ���� �� ���� �ӵ� ����
        Rigidbody rb = player.GetRigidbody();
        rb.velocity = new Vector3(0f, rb.velocity.y, 0f);
    }

    public void Update()
    {
        if(player.ShouldFall())
        {
            player.ChangeState(new FallState(player));
            return;
        }

        if (player.HasMoveInput())
        {
            player.ChangeState(new MoveState(player));
            return;
        }

        if (player.CanJump())
        {
            player.ConsumeJumpBuffer();
            player.ChangeState(new JumpState(player));
            return;
        }

        // Dash ��ȯ
        if (player.DashPressed() && player.CanDash())
        {
            player.ChangeState(new DashState(player));
            return;
        }
    }

    public void Exit()
    {

    }
}