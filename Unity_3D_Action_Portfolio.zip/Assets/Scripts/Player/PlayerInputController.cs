using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInputController : MonoBehaviour
{
    public Vector2 MouseDelta { get; private set; }
    public Vector2 MoveInput { get; private set; }
    public bool JumpPressed { get; private set; }
    public bool JumpHold { get; private set; }
    public bool RunPressed { get; private set; }
    public bool DashPressed { get; private set; }
    public bool InteractPressed { get; private set; }

    public bool ConsumeJump()
    {
        if (JumpPressed)
        {
            JumpPressed = false;
            return true;
        }
        return false;
    }

    public bool ConsumeDash()
    {
        if (DashPressed)
        {
            DashPressed = false;
            return true;
        }
        return false;
    }

    // ��ȣ�ۿ� �Է� �Һ�
    public void ConsumeInteract()
    {
        InteractPressed = false;
    }

    void Update()
    {
        // �̵� �Է� ����
        MoveInput = new Vector2(
            Input.GetAxisRaw("Horizontal"),
            Input.GetAxisRaw("Vertical")
            );

        // ���� �Է� ����
        if (Input.GetKeyDown(KeyCode.Space))
        {
            JumpPressed = true;
        }

        JumpHold = Input.GetKey(KeyCode.Space);

        // �޸��� �Է� ����
        RunPressed = Input.GetKey(KeyCode.LeftShift);

        // ���콺 �Է� ����
        MouseDelta = new Vector2(
            Input.GetAxis("Mouse X"),
            Input.GetAxis("Mouse Y")
            );

        // �뽬
        if (Input.GetKeyDown(KeyCode.LeftControl))
        {
            DashPressed = true;
        }

        // InteractPressed = Input.GetKeyDown(KeyCode.E);
        if (Input.GetKeyDown(KeyCode.E))
        {
            InteractPressed = true;
        }
    }
}
